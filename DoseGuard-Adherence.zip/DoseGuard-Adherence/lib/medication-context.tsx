import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import { scheduleNotificationsForMedication, cancelNotificationsForMedication, rescheduleAllNotifications, sendImmediateTestNotification } from './notifications';

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  times: string[];
  totalPills: number;
  remainingPills: number;
  refillThreshold: number;
  createdAt: string;
}

export interface DoseLog {
  id: string;
  medicationId: string;
  scheduledTime: string;
  status: 'taken' | 'missed' | 'upcoming' | 'skipped';
  takenAt?: string;
  date: string;
}

interface MedicationContextValue {
  medications: Medication[];
  doseLogs: DoseLog[];
  isLoading: boolean;
  addMedication: (med: Omit<Medication, 'id' | 'createdAt'>) => Promise<void>;
  removeMedication: (id: string) => Promise<void>;
  updateMedication: (id: string, updates: Partial<Medication>) => Promise<void>;
  updateMedicationTimes: (id: string, newTimes: string[]) => Promise<void>;
  markDose: (logId: string, status: 'taken' | 'missed' | 'skipped') => Promise<void>;
  getTodayLogs: () => DoseLog[];
  getAdherenceRate: (days?: number) => number;
  getStreak: () => number;
  getNextDose: () => { medication: Medication; log: DoseLog; minutesUntil: number } | null;
  getRefillAlerts: () => Medication[];
  generateDailyLogs: () => Promise<void>;
}

const MedicationContext = createContext<MedicationContextValue | null>(null);

const MEDS_KEY = '@doseguard_medications';
const LOGS_KEY = '@doseguard_dose_logs';

function getToday(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

function getCurrentMinutes(): number {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

export function MedicationProvider({ children }: { children: ReactNode }) {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [doseLogs, setDoseLogs] = useState<DoseLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [medsStr, logsStr] = await Promise.all([
        AsyncStorage.getItem(MEDS_KEY),
        AsyncStorage.getItem(LOGS_KEY),
      ]);
      const loadedMeds = medsStr ? JSON.parse(medsStr) : [];
      const loadedLogs = logsStr ? JSON.parse(logsStr) : [];
      setMedications(loadedMeds);
      setDoseLogs(loadedLogs);

      if (loadedMeds.length > 0 && Platform.OS !== 'web') {
        rescheduleAllNotifications(loadedMeds).catch(console.error);
      }
    } catch (e) {
      console.error('Failed to load medication data:', e);
    } finally {
      setIsLoading(false);
    }
  }

  async function saveMeds(meds: Medication[]) {
    await AsyncStorage.setItem(MEDS_KEY, JSON.stringify(meds));
    setMedications(meds);
  }

  async function saveLogs(logs: DoseLog[]) {
    await AsyncStorage.setItem(LOGS_KEY, JSON.stringify(logs));
    setDoseLogs(logs);
  }

  const addMedication = useCallback(async (med: Omit<Medication, 'id' | 'createdAt'>) => {
    const newMed: Medication = {
      ...med,
      id: Crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    const updated = [...medications, newMed];
    await saveMeds(updated);

    const today = getToday();
    const currentMin = getCurrentMinutes();
    const newLogs: DoseLog[] = med.times.map(time => ({
      id: Crypto.randomUUID(),
      medicationId: newMed.id,
      scheduledTime: time,
      status: timeToMinutes(time) < currentMin ? 'missed' : 'upcoming' as DoseLog['status'],
      date: today,
    }));
    const allLogs = [...doseLogs, ...newLogs];
    await saveLogs(allLogs);

    scheduleNotificationsForMedication(newMed).catch(console.error);
  }, [medications, doseLogs]);

  const removeMedication = useCallback(async (id: string) => {
    const updatedMeds = medications.filter(m => m.id !== id);
    const updatedLogs = doseLogs.filter(l => l.medicationId !== id);
    await saveMeds(updatedMeds);
    await saveLogs(updatedLogs);

    cancelNotificationsForMedication(id).catch(console.error);
  }, [medications, doseLogs]);

  const updateMedication = useCallback(async (id: string, updates: Partial<Medication>) => {
    const updatedMeds = medications.map(m => m.id === id ? { ...m, ...updates } : m);
    await saveMeds(updatedMeds);
  }, [medications]);

  const updateMedicationTimes = useCallback(async (id: string, newTimes: string[]) => {
    const newMedsList = medications.map(m => m.id === id ? { ...m, times: newTimes } : m);
    await saveMeds(newMedsList);

    const today = getToday();
    const currentMin = getCurrentMinutes();
    const existingTodayLogs = doseLogs.filter(l => l.medicationId === id && l.date === today);
    const existingTimeSet = new Set(existingTodayLogs.map(l => l.scheduledTime));

    const removedTimes = existingTodayLogs.filter(l => !newTimes.includes(l.scheduledTime) && l.status === 'upcoming');
    const addedTimes = newTimes.filter(t => !existingTimeSet.has(t));

    let updatedLogs = doseLogs.filter(l => !removedTimes.some(r => r.id === l.id));

    const newLogs: DoseLog[] = addedTimes.map(time => ({
      id: Crypto.randomUUID(),
      medicationId: id,
      scheduledTime: time,
      status: timeToMinutes(time) < currentMin ? 'missed' : 'upcoming' as DoseLog['status'],
      date: today,
    }));

    updatedLogs = [...updatedLogs, ...newLogs];
    await saveLogs(updatedLogs);

    const targetMed = newMedsList.find(m => m.id === id);
    if (targetMed) {
      await cancelNotificationsForMedication(id);
      await scheduleNotificationsForMedication(targetMed);
    }
  }, [medications, doseLogs]);

  const markDose = useCallback(async (logId: string, status: 'taken' | 'missed' | 'skipped') => {
    const log = doseLogs.find(l => l.id === logId);
    const updatedLogs = doseLogs.map(l => {
      if (l.id !== logId) return l;
      const updated: DoseLog = { ...l, status };
      if (status === 'taken') {
        updated.takenAt = new Date().toISOString();
      }
      return updated;
    });

    if (status === 'taken' && log) {
      const med = medications.find(m => m.id === log.medicationId);
      if (med) {
        if (med.remainingPills > 0) {
          const newMeds = medications.map(m =>
            m.id === log.medicationId ? { ...m, remainingPills: m.remainingPills - 1 } : m
          );
          await saveMeds(newMeds);
        }
        sendImmediateTestNotification(med.name, med.dosage).catch(console.error);
      }
    }

    await saveLogs(updatedLogs);
  }, [doseLogs, medications]);

  const getTodayLogs = useCallback((): DoseLog[] => {
    const today = getToday();
    return doseLogs
      .filter(l => l.date === today)
      .sort((a, b) => timeToMinutes(a.scheduledTime) - timeToMinutes(b.scheduledTime));
  }, [doseLogs]);

  const getAdherenceRate = useCallback((days: number = 7): number => {
    const now = new Date();
    const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
    const cutoffStr = `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, '0')}-${String(cutoff.getDate()).padStart(2, '0')}`;

    const relevantLogs = doseLogs.filter(l =>
      l.date >= cutoffStr && l.date <= getToday() && l.status !== 'upcoming'
    );
    if (relevantLogs.length === 0) return 100;
    const taken = relevantLogs.filter(l => l.status === 'taken').length;
    return Math.round((taken / relevantLogs.length) * 100);
  }, [doseLogs]);

  const getStreak = useCallback((): number => {
    let streak = 0;
    const now = new Date();
    for (let i = 0; i < 365; i++) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const dayLogs = doseLogs.filter(l => l.date === dateStr && l.status !== 'upcoming');
      if (dayLogs.length === 0) {
        if (i === 0) continue;
        break;
      }
      const allTaken = dayLogs.every(l => l.status === 'taken');
      if (allTaken) streak++;
      else break;
    }
    return streak;
  }, [doseLogs]);

  const getNextDose = useCallback((): { medication: Medication; log: DoseLog; minutesUntil: number } | null => {
    const todayLogs = getTodayLogs();
    const currentMin = getCurrentMinutes();
    const upcoming = todayLogs
      .filter(l => l.status === 'upcoming')
      .sort((a, b) => timeToMinutes(a.scheduledTime) - timeToMinutes(b.scheduledTime));

    if (upcoming.length === 0) return null;
    const nextLog = upcoming[0];
    const med = medications.find(m => m.id === nextLog.medicationId);
    if (!med) return null;

    const diff = timeToMinutes(nextLog.scheduledTime) - currentMin;
    return { medication: med, log: nextLog, minutesUntil: diff > 0 ? diff : 0 };
  }, [getTodayLogs, medications]);

  const getRefillAlerts = useCallback((): Medication[] => {
    return medications.filter(m => m.remainingPills <= m.refillThreshold);
  }, [medications]);

  const generateDailyLogs = useCallback(async () => {
    const today = getToday();
    const existingToday = doseLogs.filter(l => l.date === today);
    const existingMedIds = new Set(existingToday.map(l => `${l.medicationId}-${l.scheduledTime}`));

    const newLogs: DoseLog[] = [];
    for (const med of medications) {
      for (const time of med.times) {
        const key = `${med.id}-${time}`;
        if (!existingMedIds.has(key)) {
          newLogs.push({
            id: Crypto.randomUUID(),
            medicationId: med.id,
            scheduledTime: time,
            status: 'upcoming',
            date: today,
          });
        }
      }
    }

    if (newLogs.length > 0) {
      const allLogs = [...doseLogs, ...newLogs];
      await saveLogs(allLogs);
    }
  }, [medications, doseLogs]);

  const value = useMemo(() => ({
    medications,
    doseLogs,
    isLoading,
    addMedication,
    removeMedication,
    updateMedication,
    updateMedicationTimes,
    markDose,
    getTodayLogs,
    getAdherenceRate,
    getStreak,
    getNextDose,
    getRefillAlerts,
    generateDailyLogs,
  }), [medications, doseLogs, isLoading, addMedication, removeMedication, updateMedication, updateMedicationTimes, markDose, getTodayLogs, getAdherenceRate, getStreak, getNextDose, getRefillAlerts, generateDailyLogs]);

  return (
    <MedicationContext.Provider value={value}>
      {children}
    </MedicationContext.Provider>
  );
}

export function useMedications() {
  const context = useContext(MedicationContext);
  if (!context) throw new Error('useMedications must be used within MedicationProvider');
  return context;
}
