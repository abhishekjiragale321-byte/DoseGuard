import { Platform } from 'react-native';
import type { Medication } from './medication-context';

function getNotificationsModule(): any {
  if (Platform.OS === 'web') return null;
  try {
    const moduleName = 'expo-notifications';
    return require(moduleName);
  } catch {
    return null;
  }
}

export async function setupNotificationHandler(): Promise<void> {
  if (Platform.OS === 'web') return;
  const Notifications = getNotificationsModule();
  if (!Notifications) return;

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === 'web') return false;
  const Notifications = getNotificationsModule();
  if (!Notifications) return false;

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    return false;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('medication-reminders', {
      name: 'Medication Reminders',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      sound: 'default',
    });
  }

  return true;
}

export async function scheduleNotificationsForMedication(med: Medication): Promise<string[]> {
  if (Platform.OS === 'web') return [];
  const Notifications = getNotificationsModule();
  if (!Notifications) return [];

  const hasPermission = await requestNotificationPermission();
  if (!hasPermission) return [];

  const notifIds: string[] = [];

  for (const time of med.times) {
    const [hours, minutes] = time.split(':').map(Number);

    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Time for your medication',
          body: `Take ${med.name} ${med.dosage}`,
          data: { medicationId: med.id, time },
          sound: 'default',
          ...(Platform.OS === 'android' ? { channelId: 'medication-reminders' } : {}),
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DAILY,
          hour: hours,
          minute: minutes,
        },
      });
      notifIds.push(id);
    } catch (e) {
      console.warn('Failed to schedule notification:', e);
    }
  }

  return notifIds;
}

export async function cancelNotificationsForMedication(medId: string): Promise<void> {
  if (Platform.OS === 'web') return;
  const Notifications = getNotificationsModule();
  if (!Notifications) return;

  try {
    const scheduled = await Notifications.getAllScheduledNotificationsAsync();
    for (const n of scheduled) {
      const data = n.content.data as { medicationId?: string } | undefined;
      if (data?.medicationId === medId) {
        await Notifications.cancelScheduledNotificationAsync(n.identifier);
      }
    }
  } catch (e) {
    console.warn('Failed to cancel notifications:', e);
  }
}

export async function rescheduleAllNotifications(medications: Medication[]): Promise<void> {
  if (Platform.OS === 'web') return;
  const Notifications = getNotificationsModule();
  if (!Notifications) return;

  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
  } catch (e) {
    console.warn('Failed to cancel all notifications:', e);
  }

  const hasPermission = await requestNotificationPermission();
  if (!hasPermission) return;

  for (const med of medications) {
    await scheduleNotificationsForMedication(med);
  }
}

export async function sendImmediateTestNotification(medName: string, dosage: string): Promise<void> {
  if (Platform.OS === 'web') return;
  const Notifications = getNotificationsModule();
  if (!Notifications) return;

  const hasPermission = await requestNotificationPermission();
  if (!hasPermission) return;

  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Dose Recorded',
        body: `${medName} ${dosage} marked as taken`,
        sound: 'default',
        ...(Platform.OS === 'android' ? { channelId: 'medication-reminders' } : {}),
      },
      trigger: null,
    });
  } catch (e) {
    console.warn('Failed to send notification:', e);
  }
}
