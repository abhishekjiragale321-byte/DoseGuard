# DoseGuard - Medication Reminder App

## Overview

DoseGuard is a medication management and reminder mobile application built with Expo (React Native). It helps patients track their medication schedules, log doses (taken/missed/skipped), monitor adherence statistics, and receive notification reminders. The app supports both patient and caregiver roles, with features like prescription scanning, pill count tracking, refill alerts, and streak tracking.

The project uses a hybrid architecture: an Expo/React Native frontend for the mobile UI with local-first data storage (AsyncStorage), and an Express.js backend server with PostgreSQL database support (via Drizzle ORM) for future server-side features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Expo / React Native)

- **Framework**: Expo SDK 54 with React Native 0.81, using the new architecture (`newArchEnabled: true`)
- **Routing**: Expo Router with file-based routing (`app/` directory). Uses typed routes and the React Compiler experiment.
- **Navigation Structure**:
  - `app/index.tsx` — Login screen (name, phone, OTP flow)
  - `app/setup.tsx` — First-time medication setup (scan prescription or add manually)
  - `app/(tabs)/` — Main tab navigation with 4 tabs: Home, Add, Stats, Profile
- **State Management**: React Context API for auth (`lib/auth-context.tsx`) and medications (`lib/medication-context.tsx`), plus TanStack React Query for server data fetching
- **Data Persistence**: AsyncStorage for local user profile and medication/dose log data. All medication CRUD and dose logging currently happens client-side.
- **Notifications**: expo-notifications for scheduled medication reminders (native only, gracefully skipped on web)
- **UI/Styling**: Custom StyleSheet-based styling with a consistent color system (`constants/colors.ts`). Uses Inter font family (Google Fonts), Ionicons/Feather icons, react-native-reanimated for animations, expo-haptics for tactile feedback.
- **Platform Support**: iOS, Android, and Web. Platform-specific adjustments throughout (e.g., web insets, keyboard handling, notification guards).

### Backend (Express.js)

- **Server**: Express 5 running on Node.js (`server/index.ts`)
- **API Pattern**: Routes registered in `server/routes.ts`, prefixed with `/api`. Currently minimal — mostly scaffolding.
- **CORS**: Dynamic CORS setup supporting Replit dev/deployment domains and localhost for Expo web development
- **Storage**: In-memory storage class (`server/storage.ts`) implementing an `IStorage` interface with basic user CRUD. Designed to be swapped for database-backed storage.
- **Static Serving**: In production, serves a landing page template and static web build assets
- **Build**: Server bundled with esbuild for production (`server_dist/`)

### Database (PostgreSQL + Drizzle ORM)

- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` — currently has a `users` table with id (UUID), username, and password
- **Validation**: Uses drizzle-zod for schema-to-Zod validation (insertUserSchema)
- **Migrations**: Output to `./migrations/` directory via `drizzle-kit push`
- **Note**: The database schema is minimal. Most app data (medications, dose logs) is currently stored client-side in AsyncStorage. The server/database infrastructure is in place for future server-side features.

### Authentication

- **Current Implementation**: Simple local auth flow — user enters name and phone number, receives a simulated OTP (no real SMS integration), profile stored in AsyncStorage
- **No server-side auth**: The `users` table exists in the schema but isn't connected to the mobile auth flow yet
- **First-time flow**: After login, new users are routed to a setup screen before accessing the main app

### Key Design Decisions

1. **Local-first data**: Medications and dose logs are stored in AsyncStorage rather than synced to the server. This provides offline functionality but means data is device-local only. Server sync could be added later.
2. **Context over Redux**: Uses React Context for state management, keeping things simple for the current scope.
3. **Platform-adaptive UI**: The tab layout uses native tabs (NativeTabs) when available (iOS with liquid glass) and falls back to classic Tabs otherwise.
4. **Notification abstraction**: Notification module is dynamically required to avoid crashes on web platform.

## External Dependencies

- **Database**: PostgreSQL (via `DATABASE_URL` environment variable), accessed through Drizzle ORM
- **Fonts**: @expo-google-fonts/inter (Inter family)
- **Key Libraries**:
  - `expo-notifications` — Local push notifications for medication reminders
  - `expo-image-picker` — For prescription scanning feature
  - `expo-haptics` — Tactile feedback
  - `expo-crypto` — UUID generation for local IDs
  - `react-native-reanimated` — Animations
  - `react-native-gesture-handler` — Gesture support
  - `@tanstack/react-query` — Server state management
  - `@react-native-async-storage/async-storage` — Local data persistence
  - `http-proxy-middleware` — Dev server proxying
  - `patch-package` — Post-install patching
- **No external APIs**: No SMS/OTP service, no cloud sync, no third-party medication databases currently integrated
- **Deployment**: Configured for Replit environment (uses REPLIT_DEV_DOMAIN, REPLIT_DOMAINS environment variables)