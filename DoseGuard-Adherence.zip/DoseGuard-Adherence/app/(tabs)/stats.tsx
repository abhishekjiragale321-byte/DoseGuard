import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import Colors from '@/constants/colors';
import { useMedications } from '@/lib/medication-context';

function StatBox({ icon, iconColor, value, label, bg }: { icon: string; iconColor: string; value: string; label: string; bg: string }) {
  return (
    <View style={[styles.statBox, { backgroundColor: bg }]}>
      <Ionicons name={icon as any} size={22} color={iconColor} />
      <Text style={styles.statBoxValue}>{value}</Text>
      <Text style={styles.statBoxLabel}>{label}</Text>
    </View>
  );
}

function DayBar({ day, value, maxValue }: { day: string; value: number; maxValue: number }) {
  const height = maxValue > 0 ? Math.max((value / maxValue) * 100, 4) : 4;
  const color = value >= 80 ? Colors.success : value >= 50 ? Colors.warning : value > 0 ? Colors.danger : Colors.surfaceElevated;

  return (
    <View style={styles.dayBarContainer}>
      <View style={styles.dayBarTrack}>
        <View style={[styles.dayBarFill, { height: `${height}%`, backgroundColor: color }]} />
      </View>
      <Text style={styles.dayBarLabel}>{day}</Text>
    </View>
  );
}

export default function StatsScreen() {
  const insets = useSafeAreaInsets();
  const { doseLogs, medications, getAdherenceRate, getStreak } = useMedications();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const weeklyData = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const now = new Date();
    const result: { day: string; value: number }[] = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const dayLogs = doseLogs.filter(l => l.date === dateStr && l.status !== 'upcoming');
      const taken = dayLogs.filter(l => l.status === 'taken').length;
      const rate = dayLogs.length > 0 ? Math.round((taken / dayLogs.length) * 100) : 0;
      result.push({ day: days[d.getDay()], value: rate });
    }
    return result;
  }, [doseLogs]);

  const totalDoses = doseLogs.filter(l => l.status !== 'upcoming').length;
  const takenDoses = doseLogs.filter(l => l.status === 'taken').length;
  const missedDoses = doseLogs.filter(l => l.status === 'missed').length;
  const adherence7 = getAdherenceRate(7);
  const adherence30 = getAdherenceRate(30);
  const streak = getStreak();

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{
        paddingTop: (insets.top || webTopInset) + 16,
        paddingBottom: 100,
      }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.screenTitle}>Statistics</Text>

      <Animated.View entering={FadeInDown.duration(300)} style={styles.overviewRow}>
        <StatBox icon="checkmark-circle" iconColor={Colors.success} value={`${adherence7}%`} label="7-Day Rate" bg={Colors.successBg} />
        <StatBox icon="flame" iconColor={Colors.warning} value={`${streak}`} label="Day Streak" bg={Colors.warningBg} />
        <StatBox icon="medical" iconColor={Colors.primary} value={`${medications.length}`} label="Medicines" bg={Colors.primarySoft} />
      </Animated.View>

      <Animated.View entering={FadeInDown.duration(300).delay(100)} style={styles.chartCard}>
        <Text style={styles.chartTitle}>Weekly Adherence</Text>
        <View style={styles.chartContainer}>
          {weeklyData.map((item, idx) => (
            <DayBar key={idx} day={item.day} value={item.value} maxValue={100} />
          ))}
        </View>
      </Animated.View>

      <Animated.View entering={FadeInDown.duration(300).delay(200)} style={styles.detailCard}>
        <Text style={styles.detailTitle}>Overview</Text>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>30-Day Adherence</Text>
          <Text style={[styles.detailValue, { color: adherence30 >= 80 ? Colors.success : Colors.warning }]}>{adherence30}%</Text>
        </View>
        <View style={styles.detailDivider} />
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Total Doses Recorded</Text>
          <Text style={styles.detailValue}>{totalDoses}</Text>
        </View>
        <View style={styles.detailDivider} />
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Doses Taken</Text>
          <Text style={[styles.detailValue, { color: Colors.success }]}>{takenDoses}</Text>
        </View>
        <View style={styles.detailDivider} />
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Doses Missed</Text>
          <Text style={[styles.detailValue, { color: Colors.danger }]}>{missedDoses}</Text>
        </View>
      </Animated.View>

      {medications.length === 0 && (
        <View style={styles.emptyState}>
          <Ionicons name="bar-chart-outline" size={40} color={Colors.textTertiary} />
          <Text style={styles.emptyText}>No data yet</Text>
          <Text style={styles.emptySubtext}>Add medications to start tracking your adherence</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 20,
  },
  screenTitle: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 20,
  },
  overviewRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  statBox: {
    flex: 1,
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 6,
  },
  statBoxValue: {
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
  },
  statBoxLabel: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
  },
  chartCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
    marginBottom: 16,
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 120,
    gap: 6,
  },
  dayBarContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
  },
  dayBarTrack: {
    flex: 1,
    width: '100%',
    backgroundColor: Colors.surfaceElevated,
    borderRadius: 6,
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  dayBarFill: {
    width: '100%',
    borderRadius: 6,
  },
  dayBarLabel: {
    fontSize: 10,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textTertiary,
  },
  detailCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  detailTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
    marginBottom: 14,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
  },
  detailValue: {
    fontSize: 15,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
  },
  detailDivider: {
    height: 1,
    backgroundColor: Colors.borderLight,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  emptySubtext: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
});
