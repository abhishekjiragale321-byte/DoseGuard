import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ScrollView, Platform, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateProfile, logout } = useAuth();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [caregiverPhone, setCaregiverPhone] = useState(user?.caregiverPhone || '');
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  async function handleSave() {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await updateProfile({ name: name.trim(), caregiverPhone: caregiverPhone.trim() });
    setEditing(false);
  }

  function handleLogout() {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          await logout();
          router.replace('/');
        },
      },
    ]);
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{
        paddingTop: (insets.top || webTopInset) + 16,
        paddingBottom: 100,
      }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.screenTitle}>Profile</Text>

      <Animated.View entering={FadeInDown.duration(300)} style={styles.avatarSection}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={36} color={Colors.primary} />
        </View>
        <Text style={styles.profileName}>{user?.name || 'User'}</Text>
        <View style={styles.roleBadge}>
          <Ionicons name={user?.role === 'caregiver' ? 'people' : 'person'} size={12} color={Colors.primary} />
          <Text style={styles.roleText}>{user?.role === 'caregiver' ? 'Caregiver' : 'Patient'}</Text>
        </View>
      </Animated.View>

      <Animated.View entering={FadeInDown.duration(300).delay(100)} style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Personal Details</Text>
          <Pressable onPress={() => { setEditing(!editing); Haptics.selectionAsync(); }}>
            <Feather name={editing ? 'x' : 'edit-2'} size={18} color={Colors.primary} />
          </Pressable>
        </View>

        <View style={styles.field}>
          <Feather name="user" size={16} color={Colors.textTertiary} />
          {editing ? (
            <TextInput
              style={styles.fieldInput}
              value={name}
              onChangeText={setName}
              placeholder="Your name"
              placeholderTextColor={Colors.textTertiary}
            />
          ) : (
            <Text style={styles.fieldValue}>{user?.name}</Text>
          )}
        </View>

        <View style={styles.fieldDivider} />

        <View style={styles.field}>
          <Feather name="phone" size={16} color={Colors.textTertiary} />
          <Text style={styles.fieldValue}>{user?.countryCode} {user?.phone}</Text>
        </View>

        <View style={styles.fieldDivider} />

        <View style={styles.field}>
          <Feather name="users" size={16} color={Colors.textTertiary} />
          {editing ? (
            <TextInput
              style={styles.fieldInput}
              value={caregiverPhone}
              onChangeText={setCaregiverPhone}
              placeholder="Caregiver phone number"
              placeholderTextColor={Colors.textTertiary}
              keyboardType="phone-pad"
            />
          ) : (
            <Text style={styles.fieldValue}>
              {user?.caregiverPhone || 'No caregiver contact'}
            </Text>
          )}
        </View>

        {editing && (
          <Pressable
            style={({ pressed }) => [styles.saveButton, pressed && { opacity: 0.9 }]}
            onPress={handleSave}
          >
            <Text style={styles.saveButtonText}>Save Changes</Text>
          </Pressable>
        )}
      </Animated.View>

      <Animated.View entering={FadeInDown.duration(300).delay(200)} style={styles.card}>
        <Pressable style={styles.menuItem} onPress={() => Haptics.selectionAsync()}>
          <Feather name="shield" size={18} color={Colors.textSecondary} />
          <Text style={styles.menuText}>Privacy Policy</Text>
          <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
        </Pressable>

        <View style={styles.fieldDivider} />

        <Pressable style={styles.menuItem} onPress={() => Haptics.selectionAsync()}>
          <Feather name="file-text" size={18} color={Colors.textSecondary} />
          <Text style={styles.menuText}>Terms of Service</Text>
          <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
        </Pressable>

        <View style={styles.fieldDivider} />

        <Pressable style={styles.menuItem} onPress={() => Haptics.selectionAsync()}>
          <Feather name="info" size={18} color={Colors.textSecondary} />
          <Text style={styles.menuText}>About DoseGuard</Text>
          <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
        </Pressable>
      </Animated.View>

      <Animated.View entering={FadeInDown.duration(300).delay(300)}>
        <Pressable
          style={({ pressed }) => [styles.logoutButton, pressed && { opacity: 0.9 }]}
          onPress={handleLogout}
        >
          <Feather name="log-out" size={18} color={Colors.danger} />
          <Text style={styles.logoutText}>Logout</Text>
        </Pressable>
      </Animated.View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>DoseGuard v1.0</Text>
        <Text style={styles.footerText}>Built in alignment with DPDP 2023</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 20,
  },
  screenTitle: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 20,
  },
  avatarSection: {
    alignItems: 'center',
    marginBottom: 24,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 6,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  roleText: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.primaryDark,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
  },
  fieldValue: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    flex: 1,
  },
  fieldInput: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    borderBottomWidth: 1,
    borderBottomColor: Colors.primary,
    paddingVertical: 4,
  },
  fieldDivider: {
    height: 1,
    backgroundColor: Colors.borderLight,
  },
  saveButton: {
    height: 44,
    backgroundColor: Colors.primary,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },
  saveButtonText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
  },
  menuText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    flex: 1,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    backgroundColor: Colors.dangerBg,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FECACA',
    marginBottom: 24,
  },
  logoutText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.danger,
  },
  footer: {
    alignItems: 'center',
    gap: 4,
    marginBottom: 20,
  },
  footerText: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    color: Colors.textTertiary,
  },
});
