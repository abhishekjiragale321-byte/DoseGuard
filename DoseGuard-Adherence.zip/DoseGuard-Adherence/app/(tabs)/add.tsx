import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ScrollView, Platform, Alert, KeyboardAvoidingView, Modal, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import Animated, { FadeInDown } from 'react-native-reanimated';
import Colors from '@/constants/colors';
import { useMedications, Medication } from '@/lib/medication-context';

const TIME_OPTIONS = [
  '06:00', '06:30', '07:00', '07:30', '08:00', '08:30',
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
  '15:00', '15:30', '16:00', '16:30', '17:00', '17:30',
  '18:00', '18:30', '19:00', '19:30', '20:00', '20:30',
  '21:00', '21:30', '22:00', '22:30', '23:00', '23:30',
];

function formatTimeLabel(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

function EditTimesModal({ visible, onClose, medication, onSave }: {
  visible: boolean;
  onClose: () => void;
  medication: Medication | null;
  onSave: (id: string, times: string[]) => void;
}) {
  const [editTimes, setEditTimes] = useState<string[]>(medication?.times || []);
  const insets = useSafeAreaInsets();

  React.useEffect(() => {
    if (medication) setEditTimes([...medication.times]);
  }, [medication]);

  function toggleEditTime(time: string) {
    Haptics.selectionAsync();
    setEditTimes(prev =>
      prev.includes(time)
        ? prev.filter(t => t !== time)
        : [...prev, time].sort()
    );
  }

  if (!medication) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={editStyles.overlay}>
        <View style={[editStyles.sheet, { paddingBottom: insets.bottom + 20 }]}>
          <View style={editStyles.handle} />
          <View style={editStyles.header}>
            <Text style={editStyles.title}>Edit Schedule</Text>
            <Pressable onPress={onClose}>
              <Ionicons name="close" size={24} color={Colors.text} />
            </Pressable>
          </View>

          <Text style={editStyles.medName}>{medication.name} {medication.dosage}</Text>

          <Text style={editStyles.label}>Select Times</Text>
          <ScrollView style={{ maxHeight: 300 }} showsVerticalScrollIndicator={false}>
            <View style={editStyles.timeGrid}>
              {TIME_OPTIONS.map(time => (
                <Pressable
                  key={time}
                  style={[editStyles.timeChip, editTimes.includes(time) && editStyles.timeChipSelected]}
                  onPress={() => toggleEditTime(time)}
                >
                  <Text style={[editStyles.timeChipText, editTimes.includes(time) && editStyles.timeChipTextSelected]}>
                    {formatTimeLabel(time)}
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>

          <View style={editStyles.selectedRow}>
            <Ionicons name="time" size={16} color={Colors.primary} />
            <Text style={editStyles.selectedText}>
              {editTimes.length > 0 ? editTimes.map(formatTimeLabel).join(', ') : 'No times selected'}
            </Text>
          </View>

          <Pressable
            style={[editStyles.saveBtn, editTimes.length === 0 && { backgroundColor: Colors.textTertiary }]}
            onPress={() => {
              if (editTimes.length === 0) {
                Alert.alert('Error', 'Select at least one time.');
                return;
              }
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              onSave(medication.id, editTimes);
              onClose();
            }}
            disabled={editTimes.length === 0}
          >
            <Ionicons name="checkmark-circle" size={20} color={Colors.white} />
            <Text style={editStyles.saveBtnText}>Update Schedule</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

export default function AddScreen() {
  const insets = useSafeAreaInsets();
  const { addMedication, medications, removeMedication, updateMedicationTimes } = useMedications();
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [selectedTimes, setSelectedTimes] = useState<string[]>(['08:00']);
  const [totalPills, setTotalPills] = useState('30');
  const [refillThreshold, setRefillThreshold] = useState('5');
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [saving, setSaving] = useState(false);
  const [prescriptionImage, setPrescriptionImage] = useState<string | null>(null);
  const [editingMed, setEditingMed] = useState<Medication | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  function toggleTime(time: string) {
    Haptics.selectionAsync();
    setSelectedTimes(prev =>
      prev.includes(time)
        ? prev.filter(t => t !== time)
        : [...prev, time].sort()
    );
  }

  async function handleScanPrescription() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      const mediaResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (mediaResult.status !== 'granted') {
        Alert.alert('Permission Required', 'Camera or photo library access is needed to scan prescriptions.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        setPrescriptionImage(result.assets[0].uri);
        Alert.alert(
          'Prescription Scanned',
          'Your prescription image has been captured. Please enter the medication details from the prescription below.',
          [{ text: 'OK' }]
        );
      }
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['images'],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setPrescriptionImage(result.assets[0].uri);
      Alert.alert(
        'Prescription Scanned',
        'Your prescription image has been captured. Please enter the medication details from the prescription below.',
        [{ text: 'OK' }]
      );
    }
  }

  async function handlePickFromGallery() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Photo library access is needed to select prescription images.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setPrescriptionImage(result.assets[0].uri);
    }
  }

  async function handleSave() {
    if (!name.trim() || !dosage.trim() || selectedTimes.length === 0) {
      Alert.alert('Missing Info', 'Please fill in all fields and select at least one time.');
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setSaving(true);
    await addMedication({
      name: name.trim(),
      dosage: dosage.trim(),
      times: selectedTimes,
      totalPills: parseInt(totalPills) || 30,
      remainingPills: parseInt(totalPills) || 30,
      refillThreshold: parseInt(refillThreshold) || 5,
    });
    setName('');
    setDosage('');
    setSelectedTimes(['08:00']);
    setTotalPills('30');
    setRefillThreshold('5');
    setPrescriptionImage(null);
    setSaving(false);
    Alert.alert('Medication Added', 'Reminders have been set for your medication schedule.');
  }

  async function handleDelete(id: string, medName: string) {
    Alert.alert('Remove Medication', `Are you sure you want to remove ${medName}? This will also cancel its reminders.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          await removeMedication(id);
        },
      },
    ]);
  }

  function handleEditSchedule(med: Medication) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setEditingMed(med);
    setShowEditModal(true);
  }

  async function handleSaveEditTimes(id: string, times: string[]) {
    await updateMedicationTimes(id, times);
    Alert.alert('Schedule Updated', 'Your medication reminders have been updated.');
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.container}
        contentContainerStyle={{
          paddingTop: (insets.top || webTopInset) + 16,
          paddingBottom: 100,
        }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.screenTitle}>Add Medication</Text>

        <Animated.View entering={FadeInDown.duration(300)} style={styles.scanSection}>
          <Text style={styles.scanLabel}>Scan Prescription</Text>
          <View style={styles.scanButtonsRow}>
            <Pressable
              style={({ pressed }) => [styles.scanButton, pressed && { opacity: 0.9, transform: [{ scale: 0.97 }] }]}
              onPress={handleScanPrescription}
            >
              <View style={styles.scanIconCircle}>
                <Ionicons name="camera" size={24} color={Colors.primary} />
              </View>
              <Text style={styles.scanButtonText}>Take Photo</Text>
            </Pressable>

            <Pressable
              style={({ pressed }) => [styles.scanButton, pressed && { opacity: 0.9, transform: [{ scale: 0.97 }] }]}
              onPress={handlePickFromGallery}
            >
              <View style={[styles.scanIconCircle, { backgroundColor: Colors.warningBg }]}>
                <Ionicons name="images" size={24} color={Colors.warning} />
              </View>
              <Text style={styles.scanButtonText}>Gallery</Text>
            </Pressable>
          </View>

          {prescriptionImage && (
            <View style={styles.prescriptionPreview}>
              <Image source={{ uri: prescriptionImage }} style={styles.prescriptionImage} resizeMode="cover" />
              <Pressable style={styles.removeImageBtn} onPress={() => setPrescriptionImage(null)}>
                <Ionicons name="close-circle" size={24} color={Colors.danger} />
              </Pressable>
            </View>
          )}
        </Animated.View>

        <Animated.View entering={FadeInDown.duration(300).delay(100)} style={styles.formCard}>
          <Text style={styles.formTitle}>Medication Details</Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Medicine Name</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. Paracetamol"
              placeholderTextColor={Colors.textTertiary}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Dosage</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. 650mg"
              placeholderTextColor={Colors.textTertiary}
              value={dosage}
              onChangeText={setDosage}
            />
          </View>

          <View style={styles.inputGroup}>
            <View style={styles.labelRow}>
              <Text style={styles.label}>Schedule Times</Text>
              <Pressable onPress={() => { setShowTimePicker(!showTimePicker); Haptics.selectionAsync(); }}>
                <Text style={styles.toggleText}>{showTimePicker ? 'Done' : 'Select Times'}</Text>
              </Pressable>
            </View>

            <View style={styles.selectedTimes}>
              {selectedTimes.map(time => (
                <View key={time} style={styles.timeBadge}>
                  <Ionicons name="time" size={12} color={Colors.primary} />
                  <Text style={styles.timeBadgeText}>{formatTimeLabel(time)}</Text>
                  <Pressable onPress={() => toggleTime(time)}>
                    <Ionicons name="close-circle" size={16} color={Colors.textTertiary} />
                  </Pressable>
                </View>
              ))}
              {selectedTimes.length === 0 && (
                <Text style={styles.noTimeText}>No times selected</Text>
              )}
            </View>

            {showTimePicker && (
              <View style={styles.timeGrid}>
                {TIME_OPTIONS.map(time => (
                  <Pressable
                    key={time}
                    style={[styles.timeChip, selectedTimes.includes(time) && styles.timeChipSelected]}
                    onPress={() => toggleTime(time)}
                  >
                    <Text style={[styles.timeChipText, selectedTimes.includes(time) && styles.timeChipTextSelected]}>
                      {formatTimeLabel(time)}
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <View style={styles.rowInputs}>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={styles.label}>Total Pills</Text>
              <TextInput
                style={styles.input}
                placeholder="30"
                placeholderTextColor={Colors.textTertiary}
                value={totalPills}
                onChangeText={t => setTotalPills(t.replace(/[^0-9]/g, ''))}
                keyboardType="number-pad"
              />
            </View>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={styles.label}>Refill Alert At</Text>
              <TextInput
                style={styles.input}
                placeholder="5"
                placeholderTextColor={Colors.textTertiary}
                value={refillThreshold}
                onChangeText={t => setRefillThreshold(t.replace(/[^0-9]/g, ''))}
                keyboardType="number-pad"
              />
            </View>
          </View>

          <View style={styles.reminderNotice}>
            <Ionicons name="notifications" size={16} color={Colors.primary} />
            <Text style={styles.reminderText}>Real-time reminders will be set automatically</Text>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.saveButton,
              (!name.trim() || !dosage.trim() || selectedTimes.length === 0) && styles.buttonDisabled,
              pressed && { opacity: 0.9, transform: [{ scale: 0.98 }] },
            ]}
            onPress={handleSave}
            disabled={!name.trim() || !dosage.trim() || selectedTimes.length === 0 || saving}
          >
            <Ionicons name="add-circle" size={20} color={Colors.white} />
            <Text style={styles.saveButtonText}>Add Medication</Text>
          </Pressable>
        </Animated.View>

        {medications.length > 0 && (
          <View>
            <Text style={styles.sectionTitle}>Your Medications ({medications.length})</Text>
            {medications.map((med, idx) => (
              <Animated.View key={med.id} entering={FadeInDown.duration(300).delay(idx * 50)} style={styles.medCard}>
                <View style={styles.medIconCircle}>
                  <Ionicons name="medical" size={20} color={Colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.medName}>{med.name}</Text>
                  <Text style={styles.medDosage}>{med.dosage}</Text>
                  <View style={styles.medTimesRow}>
                    <Ionicons name="time-outline" size={12} color={Colors.primary} />
                    <Text style={styles.medTimes}>
                      {med.times.map(formatTimeLabel).join(' / ')}
                    </Text>
                  </View>
                  <Text style={styles.medPills}>{med.remainingPills}/{med.totalPills} pills remaining</Text>
                </View>
                <View style={styles.medActions}>
                  <Pressable onPress={() => handleEditSchedule(med)} style={styles.editBtn}>
                    <Feather name="clock" size={16} color={Colors.primary} />
                  </Pressable>
                  <Pressable onPress={() => handleDelete(med.id, med.name)} style={styles.deleteBtn}>
                    <Feather name="trash-2" size={16} color={Colors.danger} />
                  </Pressable>
                </View>
              </Animated.View>
            ))}
          </View>
        )}
      </ScrollView>

      <EditTimesModal
        visible={showEditModal}
        onClose={() => setShowEditModal(false)}
        medication={editingMed}
        onSave={handleSaveEditTimes}
      />
    </KeyboardAvoidingView>
  );
}

const editStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: Colors.overlay,
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 12,
    maxHeight: '80%',
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.border,
    alignSelf: 'center',
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
  },
  medName: {
    fontSize: 15,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
    marginBottom: 16,
  },
  label: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textSecondary,
    textTransform: 'uppercase' as const,
    letterSpacing: 0.5,
    marginBottom: 10,
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surfaceElevated,
  },
  timeChipSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
  },
  timeChipText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
  },
  timeChipTextSelected: {
    color: Colors.primaryDark,
  },
  selectedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 16,
    padding: 12,
    backgroundColor: Colors.surfaceElevated,
    borderRadius: 10,
  },
  selectedText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    flex: 1,
  },
  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    backgroundColor: Colors.primary,
    borderRadius: 12,
    marginTop: 16,
  },
  saveBtnText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 20,
  },
  screenTitle: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 20,
  },
  scanSection: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  scanLabel: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
    marginBottom: 14,
  },
  scanButtonsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  scanButton: {
    flex: 1,
    alignItems: 'center',
    gap: 8,
    padding: 16,
    backgroundColor: Colors.surfaceElevated,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  scanIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanButtonText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.text,
  },
  prescriptionPreview: {
    marginTop: 14,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  prescriptionImage: {
    width: '100%',
    height: 180,
    borderRadius: 12,
  },
  removeImageBtn: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  formCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 24,
  },
  formTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textSecondary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  toggleText: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.primary,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    paddingHorizontal: 14,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    backgroundColor: Colors.surfaceElevated,
  },
  selectedTimes: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  timeBadgeText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.primaryDark,
  },
  noTimeText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.textTertiary,
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surfaceElevated,
  },
  timeChipSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
  },
  timeChipText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
  },
  timeChipTextSelected: {
    color: Colors.primaryDark,
  },
  rowInputs: {
    flexDirection: 'row',
    gap: 12,
  },
  reminderNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.primarySoft,
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
  },
  reminderText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.primaryDark,
    flex: 1,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    backgroundColor: Colors.primary,
    borderRadius: 12,
    marginTop: 4,
  },
  buttonDisabled: {
    backgroundColor: Colors.textTertiary,
  },
  saveButtonText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 14,
  },
  medCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  medIconCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  medName: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  medDosage: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
  },
  medTimesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 3,
  },
  medTimes: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    color: Colors.primary,
  },
  medPills: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    color: Colors.textTertiary,
    marginTop: 2,
  },
  medActions: {
    gap: 10,
    alignItems: 'center',
  },
  editBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.dangerBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
