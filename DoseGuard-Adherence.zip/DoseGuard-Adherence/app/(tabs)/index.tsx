import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, Pressable, StyleSheet, ScrollView, Platform, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { useMedications, DoseLog } from '@/lib/medication-context';

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

function formatTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

function formatMinutes(min: number): string {
  if (min < 60) return `${min}m`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function TimelineItem({ log, medName, onMark }: { log: DoseLog; medName: string; onMark: (id: string, status: 'taken' | 'missed') => void }) {
  const statusConfig = {
    taken: { icon: 'checkmark-circle' as const, color: Colors.taken, bg: Colors.successBg, label: 'Taken' },
    upcoming: { icon: 'time' as const, color: Colors.upcoming, bg: Colors.warningBg, label: 'Upcoming' },
    missed: { icon: 'close-circle' as const, color: Colors.missed, bg: Colors.dangerBg, label: 'Missed' },
    skipped: { icon: 'remove-circle' as const, color: Colors.textTertiary, bg: Colors.surfaceElevated, label: 'Skipped' },
  };
  const config = statusConfig[log.status];

  return (
    <View style={styles.timelineItem}>
      <View style={styles.timelineLeft}>
        <Text style={styles.timelineTime}>{formatTime(log.scheduledTime)}</Text>
      </View>
      <View style={[styles.timelineDot, { backgroundColor: config.color }]} />
      <View style={[styles.timelineCard, { borderLeftColor: config.color }]}>
        <View style={styles.timelineCardContent}>
          <View style={{ flex: 1 }}>
            <Text style={styles.timelineMed}>{medName}</Text>
            <View style={[styles.statusBadge, { backgroundColor: config.bg }]}>
              <Ionicons name={config.icon} size={12} color={config.color} />
              <Text style={[styles.statusText, { color: config.color }]}>{config.label}</Text>
            </View>
          </View>
          {log.status === 'upcoming' && (
            <View style={styles.timelineActions}>
              <Pressable
                style={styles.takeButton}
                onPress={() => onMark(log.id, 'taken')}
              >
                <Ionicons name="checkmark" size={18} color={Colors.white} />
              </Pressable>
              <Pressable
                style={styles.skipButton}
                onPress={() => onMark(log.id, 'missed')}
              >
                <Ionicons name="close" size={16} color={Colors.textTertiary} />
              </Pressable>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { medications, getTodayLogs, getNextDose, getAdherenceRate, getStreak, markDose, generateDailyLogs, getRefillAlerts } = useMedications();
  const [refreshing, setRefreshing] = useState(false);
  const [, setTick] = useState(0);

  useEffect(() => {
    generateDailyLogs();
    const interval = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(interval);
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await generateDailyLogs();
    setTick(t => t + 1);
    setRefreshing(false);
  }, [generateDailyLogs]);

  const todayLogs = getTodayLogs();
  const nextDose = getNextDose();
  const adherence = getAdherenceRate(7);
  const streak = getStreak();
  const refillAlerts = getRefillAlerts();
  const firstName = user?.name?.split(' ')[0] || 'User';

  async function handleMark(logId: string, status: 'taken' | 'missed') {
    if (status === 'taken') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    await markDose(logId, status);
  }

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{
        paddingTop: (insets.top || webTopInset) + 16,
        paddingBottom: 100,
      }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
      }
    >
      <Animated.View entering={FadeIn.duration(400)} style={styles.header}>
        <View>
          <Text style={styles.greeting}>{getGreeting()},</Text>
          <Text style={styles.userName}>{firstName}</Text>
        </View>
        <View style={styles.notifCircle}>
          <Ionicons name="notifications-outline" size={22} color={Colors.text} />
        </View>
      </Animated.View>

      {nextDose ? (
        <Animated.View entering={FadeInDown.duration(400).delay(100)} style={styles.nextDoseCard}>
          <View style={styles.nextDoseTop}>
            <Ionicons name="time-outline" size={18} color={Colors.primaryLight} />
            <Text style={styles.nextDoseLabel}>Next Dose in {formatMinutes(nextDose.minutesUntil)}</Text>
          </View>
          <Text style={styles.nextDoseName}>{nextDose.medication.name}</Text>
          <Text style={styles.nextDoseDosage}>{nextDose.medication.dosage}</Text>
          <View style={styles.nextDoseTimeRow}>
            <Text style={styles.nextDoseTime}>{formatTime(nextDose.log.scheduledTime)}</Text>
          </View>
          <Pressable
            style={({ pressed }) => [styles.takeDoseButton, pressed && { opacity: 0.9, transform: [{ scale: 0.98 }] }]}
            onPress={() => handleMark(nextDose.log.id, 'taken')}
          >
            <Ionicons name="checkmark-circle" size={20} color={Colors.white} />
            <Text style={styles.takeDoseText}>Mark as Taken</Text>
          </Pressable>
        </Animated.View>
      ) : medications.length > 0 ? (
        <Animated.View entering={FadeInDown.duration(400).delay(100)} style={styles.allDoneCard}>
          <Ionicons name="checkmark-done-circle" size={36} color={Colors.success} />
          <Text style={styles.allDoneText}>All doses completed for today</Text>
        </Animated.View>
      ) : (
        <Animated.View entering={FadeInDown.duration(400).delay(100)} style={styles.emptyCard}>
          <Ionicons name="medkit-outline" size={36} color={Colors.textTertiary} />
          <Text style={styles.emptyText}>No medications added yet</Text>
          <Text style={styles.emptySubtext}>Go to the Add tab to add your first medication</Text>
        </Animated.View>
      )}

      {refillAlerts.length > 0 && (
        <Animated.View entering={FadeInDown.duration(400).delay(150)}>
          {refillAlerts.map(med => (
            <View key={med.id} style={styles.refillCard}>
              <Ionicons name="warning" size={18} color={Colors.warning} />
              <View style={{ flex: 1 }}>
                <Text style={styles.refillTitle}>Refill Alert: {med.name}</Text>
                <Text style={styles.refillSub}>{med.remainingPills} pills remaining</Text>
              </View>
            </View>
          ))}
        </Animated.View>
      )}

      {todayLogs.length > 0 && (
        <Animated.View entering={FadeInDown.duration(400).delay(200)}>
          <Text style={styles.sectionTitle}>Today's Timeline</Text>
          <View style={styles.timeline}>
            {todayLogs.map(log => {
              const med = medications.find(m => m.id === log.medicationId);
              return (
                <TimelineItem
                  key={log.id}
                  log={log}
                  medName={med ? `${med.name} ${med.dosage}` : 'Unknown'}
                  onMark={handleMark}
                />
              );
            })}
          </View>
        </Animated.View>
      )}

      <Animated.View entering={FadeInDown.duration(400).delay(300)} style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{adherence}%</Text>
          <Text style={styles.statLabel}>Adherence</Text>
          <View style={styles.statBar}>
            <View style={[styles.statBarFill, { width: `${adherence}%`, backgroundColor: adherence >= 80 ? Colors.success : adherence >= 50 ? Colors.warning : Colors.danger }]} />
          </View>
        </View>
        <View style={styles.statCard}>
          <View style={styles.streakRow}>
            <Ionicons name="flame" size={20} color={Colors.warning} />
            <Text style={styles.statValue}>{streak}</Text>
          </View>
          <Text style={styles.statLabel}>Day Streak</Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
  },
  notifCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextDoseCard: {
    backgroundColor: Colors.primaryDark,
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
  },
  nextDoseTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  nextDoseLabel: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    color: Colors.primarySoft,
  },
  nextDoseName: {
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
    color: Colors.white,
    marginBottom: 2,
  },
  nextDoseDosage: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: 'rgba(255,255,255,0.7)',
    marginBottom: 8,
  },
  nextDoseTimeRow: {
    marginBottom: 16,
  },
  nextDoseTime: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: 'rgba(255,255,255,0.9)',
  },
  takeDoseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.success,
    height: 46,
    borderRadius: 12,
  },
  takeDoseText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
  allDoneCard: {
    backgroundColor: Colors.successBg,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#A7F3D0',
  },
  allDoneText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.success,
  },
  emptyCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  emptySubtext: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  refillCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.warningBg,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  refillTitle: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  refillSub: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 14,
    marginTop: 8,
  },
  timeline: {
    gap: 0,
    marginBottom: 20,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  timelineLeft: {
    width: 70,
    paddingTop: 10,
  },
  timelineTime: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textSecondary,
  },
  timelineDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginTop: 14,
    marginRight: 10,
  },
  timelineCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 12,
    borderLeftWidth: 3,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  timelineCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timelineMed: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
    marginBottom: 4,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
  timelineActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  takeButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.success,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skipButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  statValue: {
    fontSize: 28,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
    marginTop: 2,
  },
  statBar: {
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.surfaceElevated,
    marginTop: 10,
    overflow: 'hidden',
  },
  statBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  streakRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
});
