import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';

export default function SetupScreen() {
  const insets = useSafeAreaInsets();
  const { completeSetup } = useAuth();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  async function handleScanPrescription() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await completeSetup();
    router.replace('/(tabs)');
  }

  async function handleAddManually() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await completeSetup();
    router.replace('/(tabs)');
  }

  return (
    <View style={[styles.container, {
      paddingTop: (insets.top || webTopInset) + 40,
      paddingBottom: (insets.bottom || webBottomInset) + 20,
    }]}>
      <View style={styles.headerIcon}>
        <Ionicons name="medkit" size={40} color={Colors.primary} />
      </View>
      <Text style={styles.title}>Set Up Your Medication</Text>
      <Text style={styles.subtitle}>Get started by adding your medications</Text>

      <View style={styles.cardContainer}>
        <Pressable
          style={({ pressed }) => [styles.actionCard, pressed && styles.cardPressed]}
          onPress={handleScanPrescription}
        >
          <View style={styles.cardIconCircle}>
            <Ionicons name="camera" size={28} color={Colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Scan Prescription</Text>
          <Text style={styles.cardDesc}>Use your camera to scan a prescription</Text>
          <Ionicons name="chevron-forward" size={20} color={Colors.textTertiary} style={styles.cardArrow} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.actionCard, pressed && styles.cardPressed]}
          onPress={handleAddManually}
        >
          <View style={[styles.cardIconCircle, { backgroundColor: Colors.warningBg }]}>
            <Ionicons name="add-circle" size={28} color={Colors.warning} />
          </View>
          <Text style={styles.cardTitle}>Add Medicine Manually</Text>
          <Text style={styles.cardDesc}>Enter medication details yourself</Text>
          <Ionicons name="chevron-forward" size={20} color={Colors.textTertiary} style={styles.cardArrow} />
        </Pressable>
      </View>

      <View style={styles.footer}>
        <View style={styles.secureRow}>
          <Feather name="lock" size={14} color={Colors.textTertiary} />
          <Text style={styles.secureText}>Secure & Encrypted</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 24,
  },
  headerIcon: {
    alignSelf: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 40,
  },
  cardContainer: {
    gap: 16,
    flex: 1,
    justifyContent: 'center',
    marginTop: -60,
  },
  actionCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: Colors.border,
    flexDirection: 'column',
    alignItems: 'center',
    gap: 10,
  },
  cardPressed: {
    backgroundColor: Colors.surfaceElevated,
    transform: [{ scale: 0.98 }],
  },
  cardIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  cardTitle: {
    fontSize: 17,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.text,
  },
  cardDesc: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  cardArrow: {
    position: 'absolute',
    right: 16,
    top: '50%',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 10,
  },
  secureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  secureText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    color: Colors.textTertiary,
  },
});
