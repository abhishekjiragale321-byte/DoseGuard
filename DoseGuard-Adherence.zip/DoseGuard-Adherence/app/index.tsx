import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Platform, ActivityIndicator, KeyboardAvoidingView, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { user, isLoggedIn, isLoading, login } = useAuth();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+91');
  const [role, setRole] = useState<'patient' | 'caregiver'>('patient');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!isLoading && isLoggedIn && user) {
      if (user.isFirstTime) {
        router.replace('/setup');
      } else {
        router.replace('/(tabs)');
      }
    }
  }, [isLoading, isLoggedIn, user]);

  if (isLoading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  if (isLoggedIn) return null;

  async function handleSendOtp() {
    if (!name.trim() || phone.length < 10) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSending(true);
    await new Promise(r => setTimeout(r, 1200));
    setOtpSent(true);
    setSending(false);
  }

  async function handleVerifyOtp() {
    if (otp.length < 4) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSending(true);
    await new Promise(r => setTimeout(r, 800));
    await login({ name: name.trim(), phone, countryCode, role });
    setSending(false);
  }

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: (insets.top || webTopInset) + 40,
            paddingBottom: (insets.bottom || (Platform.OS === 'web' ? 34 : 0)) + 20,
          }
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.logoContainer}>
          <View style={styles.logoCircle}>
            <Ionicons name="shield-checkmark" size={36} color={Colors.white} />
          </View>
          <Text style={styles.appName}>DoseGuard</Text>
          <Text style={styles.tagline}>Intelligent Medication Adherence Platform</Text>
        </View>

        <View style={styles.formCard}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Name</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your name"
              placeholderTextColor={Colors.textTertiary}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone Number</Text>
            <View style={styles.phoneRow}>
              <View style={styles.countryCodeBox}>
                <Text style={styles.countryCodeText}>{countryCode}</Text>
              </View>
              <TextInput
                style={[styles.input, styles.phoneInput]}
                placeholder="10-digit number"
                placeholderTextColor={Colors.textTertiary}
                value={phone}
                onChangeText={t => setPhone(t.replace(/[^0-9]/g, '').slice(0, 10))}
                keyboardType="phone-pad"
                maxLength={10}
              />
            </View>
          </View>

          {otpSent && (
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Enter OTP</Text>
              <TextInput
                style={styles.input}
                placeholder="4-digit OTP"
                placeholderTextColor={Colors.textTertiary}
                value={otp}
                onChangeText={t => setOtp(t.replace(/[^0-9]/g, '').slice(0, 4))}
                keyboardType="number-pad"
                maxLength={4}
              />
            </View>
          )}

          {!otpSent ? (
            <Pressable
              style={({ pressed }) => [
                styles.primaryButton,
                (!name.trim() || phone.length < 10) && styles.buttonDisabled,
                pressed && styles.buttonPressed,
              ]}
              onPress={handleSendOtp}
              disabled={!name.trim() || phone.length < 10 || sending}
            >
              {sending ? (
                <ActivityIndicator color={Colors.white} size="small" />
              ) : (
                <Text style={styles.buttonText}>Send OTP</Text>
              )}
            </Pressable>
          ) : (
            <Pressable
              style={({ pressed }) => [
                styles.primaryButton,
                otp.length < 4 && styles.buttonDisabled,
                pressed && styles.buttonPressed,
              ]}
              onPress={handleVerifyOtp}
              disabled={otp.length < 4 || sending}
            >
              {sending ? (
                <ActivityIndicator color={Colors.white} size="small" />
              ) : (
                <Text style={styles.buttonText}>Verify & Login</Text>
              )}
            </Pressable>
          )}

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
          </View>

          <Text style={styles.roleLabel}>Login as:</Text>
          <View style={styles.roleRow}>
            <Pressable
              style={[styles.roleOption, role === 'patient' && styles.roleSelected]}
              onPress={() => { setRole('patient'); Haptics.selectionAsync(); }}
            >
              <View style={[styles.radio, role === 'patient' && styles.radioSelected]}>
                {role === 'patient' && <View style={styles.radioInner} />}
              </View>
              <Ionicons name="person" size={18} color={role === 'patient' ? Colors.primary : Colors.textSecondary} />
              <Text style={[styles.roleText, role === 'patient' && styles.roleTextSelected]}>Patient</Text>
            </Pressable>

            <Pressable
              style={[styles.roleOption, role === 'caregiver' && styles.roleSelected]}
              onPress={() => { setRole('caregiver'); Haptics.selectionAsync(); }}
            >
              <View style={[styles.radio, role === 'caregiver' && styles.radioSelected]}>
                {role === 'caregiver' && <View style={styles.radioInner} />}
              </View>
              <Ionicons name="people" size={18} color={role === 'caregiver' ? Colors.primary : Colors.textSecondary} />
              <Text style={[styles.roleText, role === 'caregiver' && styles.roleTextSelected]}>Caregiver</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.footer}>
          <View style={styles.secureRow}>
            <Feather name="lock" size={14} color={Colors.textTertiary} />
            <Text style={styles.secureText}>Secure & Encrypted</Text>
          </View>
          <Text style={styles.footerLinks}>Privacy Policy  |  Terms</Text>
          <Text style={styles.footerNote}>
            Built in alignment with DPDP 2023 data protection principles.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  logoCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  appName: {
    fontSize: 28,
    fontFamily: 'Inter_700Bold',
    color: Colors.text,
    marginBottom: 6,
  },
  tagline: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  formCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textSecondary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    paddingHorizontal: 14,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    backgroundColor: Colors.surfaceElevated,
  },
  phoneRow: {
    flexDirection: 'row',
    gap: 8,
  },
  countryCodeBox: {
    height: 48,
    width: 60,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.surfaceElevated,
  },
  countryCodeText: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: Colors.text,
  },
  phoneInput: {
    flex: 1,
  },
  primaryButton: {
    height: 50,
    backgroundColor: Colors.primary,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  buttonDisabled: {
    backgroundColor: Colors.textTertiary,
  },
  buttonPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  buttonText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
  divider: {
    marginVertical: 20,
  },
  dividerLine: {
    height: 1,
    backgroundColor: Colors.border,
  },
  roleLabel: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textSecondary,
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  roleRow: {
    flexDirection: 'row',
    gap: 12,
  },
  roleOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: Colors.border,
    backgroundColor: Colors.surfaceElevated,
  },
  roleSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
  },
  radio: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: Colors.textTertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioSelected: {
    borderColor: Colors.primary,
  },
  radioInner: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
  },
  roleText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: Colors.textSecondary,
  },
  roleTextSelected: {
    color: Colors.primaryDark,
  },
  footer: {
    alignItems: 'center',
    gap: 8,
  },
  secureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  secureText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    color: Colors.textTertiary,
  },
  footerLinks: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    color: Colors.textTertiary,
  },
  footerNote: {
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 14,
    maxWidth: 280,
  },
});
